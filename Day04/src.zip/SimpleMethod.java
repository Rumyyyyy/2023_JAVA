public class SimpleMethod {
	static void print_head() {
		System.out.println("------------------------------------------");
	}
	public static void main(String[] args) {
		print_head();
		System.out.println("메소드를 이용한 프로그램입니다.");
		print_head();
		System.out.println("메소드를 이용하면 프로그램을 구조화할 수 있습니다.");
		print_head();
	}
}
