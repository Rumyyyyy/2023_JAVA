import java.util.Scanner;
public class ArrayTest2 {
	public static void main(String[] args) {
		//사용자로부터 5명의 성적을 입력 받아서 평균을 구하는 프로그램을 배열을 이용하여 작성함
		final int STUDENTS = 5;
		int total = 0;
		Scanner scan = new Scanner(System.in);
		int [] scores = new int[STUDENTS]; //크기가 STUDENTS인 배열 생성
		for(int i=0;i<scores.length;i++) {
			System.out.print("성적을 입력하세요: ");
			scores[i] = scan.nextInt(); //i번째 원소에 성적을 저장함
		}
		for(int i=0;i<scores.length;i++) {
			total += scores[i];
		}
		System.out.println("평균 성적은 "+total/STUDENTS+"입니다.");
		scan.close();
	}
}
