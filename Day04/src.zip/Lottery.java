public class Lottery {
	public static void main(String[] args) {
		//45*44*43*42*41*40 = 58644432000
		//6*5*4*3*2*1 = 6!
		//로또의 경우의 수 = (45*44*43*42*41*40)/720 = 8,145,060
		int odds = 1;
		final int n = 45;
		final int k = 6;
		for(int i=1;i<=k;i++) {
			odds = odds * (n-i+1)/i;
		}
		System.out.println("로또 1등 확률: 1/"+odds);
	}
}
