public class Choice {
	public static void main(String[] args) {
		int grade = 60;
		System.out.println(grade>=60?"합격":"불합격");
	}
}
