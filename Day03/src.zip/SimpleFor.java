import java.util.Scanner;
public class SimpleFor {
	public static void main(String[] args) {
		int num, ru;
		Scanner s = new Scanner(System.in);
		System.out.print("반복할 횟수를 입력하세요: ");
		ru = s.nextInt();
		for(num=0;num<ru;num++) {
			System.out.println("for 문을 이용하여 반복 실행됩니다");
		}
		s.close();
	}
}
