import java.util.Scanner;
public class Sum1To10 {
	public static void main(String[] args) {
		int n, nu;
		int sum = 0;
		Scanner s = new Scanner(System.in);
		System.out.print("누적 합계를 알고 싶은 숫자를 입력하세요: ");
		nu = s.nextInt();
		for(n=1;n<=nu;n++) {
			sum = sum+n;
		}
		System.out.println("1부터 "+nu+"의 합은 "+sum+" 입니다.");
	}
}
