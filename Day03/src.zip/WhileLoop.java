public class WhileLoop {
	public static void main(String[] args) {
		//반복 횟수를 저장할 변수
		int count = 1;
		//while문으로 반복
		while(count<=5) {
			//"while 문을 이용하여 반복 실행됩니다." 라는 문장을 출력
			System.out.println("while 문을 이용하여 반복 실행됩니다.");
			//반복 횟수를 1 증가
			count++;
		}
	}
}
